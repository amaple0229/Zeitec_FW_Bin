/**
 * @file Customer.c
 *
 *  Customer Function
 *
 *
 * @version $Revision$
 * @author Maple Huang <maple.huang@zeitecsemi.com>
 * @note Copyright (c) 2017, Zeitec Semiconductor Ltd., all rights reserved.
 * @note
*/

#include "ZetDef.h"

#ifdef FEATURE_FORCE_TOUCH
EXTERN WORD gwForceValue[5];
#ifdef FEATURE_DEMO_FORCE_TOUCH
EXTERN BYTE gbFirstForceCounter[5];
EXTERN BYTE gbForceArea[5];
#endif
#endif

#ifdef FEATURE_ZET7101_GPIO_ISR
BYTE gbTestP2Pin5;
BYTE gbTestP2Pin6;
#endif

#ifdef FEATURE_SELF_SCAN
SelfScanValue volatile sSelfScan;
#define SELF_TRACE 4
#endif
#ifdef FEATURE_IR_SCAN
IRScanValue volatile sIRScan;
#endif

#ifdef FEATURE_ZET7101_ANA2GPIO
void ANA2GpioInit(void)
{
   ///////////////////////////////////////////
   //bit[0:12] ==> P2_0 ~ P2_12, total 13 Pin, Phyical trace(TRn) mapping in Pin table
   //AD_CTRL14: decide which Pin configure as GPIO from Analog Pin(1),    
   //P2_SEL18: decide which GPIO Pin's VDDIO as 1.8V(1) or 3.3V(0) 
   //IODIR_P2: decide which GPIO Pin configure as input(0) or output(1) Pin
   //IODIR_P2: It need to set the Analog usage PIN as output mode!!!
   //P2: set or get Pin status, High(1), Low(0).
   ///////////////////////////////////////////   
  //GPIO output case
  SET_BIT(AD_CTRL14,1<<0);	// TR7 ==> P2_0 Pin(1)
  SET_BIT(P2_SEL18,1<<0);  // P2_0 as  1.8V(1) 	
	SET_BIT(IODIR_P2,1<<0);/// P2_0 as output(1)
	SET_BIT(P2,1<<0);/// P2_0 High (1)		

	SET_BIT(AD_CTRL14,1<<1);	// TR8 ==> P2_1 Pin(1)
  SET_BIT(P2_SEL18,1<<1);  // P2_1 as  1.8V(1) 
	SET_BIT(IODIR_P2,1<<1);/// P2_1 as output(1)	
	SET_BIT(P2,1<<1);/// P2_1 High (1)

	//IODIR_P2: It need to set the Analog usage PIN as output mode!!!
	WRITE_REG16(IODIR_P2, (READ_REG16(IODIR_P2)|(~(READ_REG16(AD_CTRL14)))));	
	
  //GPIO input case
	SET_BIT(AD_CTRL14,1<<2);	// TR9 ==> P2_2 Pin(1)
	CLR_BIT(P2_SEL18,1<<2);  // P2_2 as  3.3 V(0) 
	CLR_BIT(IODIR_P2,1<<2);/// P2_2 as input(0)		
}

void ANA2GpioDataOut(BYTE bData)
{  	
	int data i;
	int data Org;
	int data temp;

	Org= READ_REG(P2);
	Org &= (~(0x01|0x02));		// simulate 0x01 Clock  0x02 Data
	//Org &= (~0x000C );  
	for(i=8;i>0;i--)
	{
	 if(i==4)
	 {
		 DELAY_1US_NOP();
	 }
	 if(bData & 1<<(i-1))
	 {
		 temp = Org | (0x01|0x02);
	 }
	 else
	 {
		 temp = Org | (0x01);
	 }
	 WRITE_REG(P2, temp);
	 DELAY_10US_NOP();
	 WRITE_REG(P2, Org);			
	}
}

#endif

#ifdef FEATURE_ZET7101_GPIO_ISR
void GpioISRInit(void)
{
   //GPIO input case & interrupt enable
	SET_BIT(AD_CTRL14,1<<5);	// TR12 ==> P2_5 Pin(1)
  CLR_BIT(P2_SEL18,1<<5);  // P2_5 as  3.3 V(0) 
	CLR_BIT(IODIR_P2,1<<5);/// P2_5 as input(0)	
	SET_BIT(P2_INT_EN,1<<5);	// P2_5 interrupt enable(1)
	SET_BIT(P2_WAKE_EN,1<<5);	// P2_5 wake-up enable(1)
	SET_BIT(P2_TRG_EDGE,1<<5); // P2_5 trigger type(1): 1:Pos-edge, 0:Neg-edge 
	CLR_BIT(P2_INT,1<<5);	// P2_5 Default clear int. first(0)

  SET_BIT(AD_CTRL14,1<<6);	// TR13 ==> P2_6 Pin(1)
  SET_BIT(P2_SEL18,1<<6);  // P2_6 as  1.8 V(1) 
	CLR_BIT(IODIR_P2,1<<6);/// P2_6 as input(0)	
	SET_BIT(P2_INT_EN,1<<6);	// P2_6 interrupt enable(1)
	SET_BIT(P2_WAKE_EN,1<<6);	// P2_6  wake-up enable(1)
	CLR_BIT(P2_TRG_EDGE,1<<6); // P2_6  trigger type(0): 1:Pos-edge, 0:Neg-edge  
	CLR_BIT(P2_INT,1<<6); // P2_6 Default clear int. first(0)

	//enable INT_P2IO Interrupt MASK, move to INT_ALL setting
	//__nds32__mtsr(INT_ALL|INT_P2IO, NDS32_SR_INT_MASK2);
	//InterruptEnable();

	//sample code test
	gbTestP2Pin5=0;
	gbTestP2Pin6=0;
}

void GpioIsr(void)
{
   if((READ_REG(P2_INT)&(1<<5))==(1<<5)) //P2_5 interrupt 
 	 {
      gbTestP2Pin5++;
		  ///--------------------------------------------///
			/// Clear interrupt flag
			///--------------------------------------------///
			CLR_BIT(P2_INT, (1<<5));  //clear P2_5 interrupt 
 	 }
	 else if((READ_REG(P2_INT)&(1<<6))==(1<<6)) //P2_6 interrupt 
 	 {
		   gbTestP2Pin6++;
			 ///--------------------------------------------///
			 /// Clear interrupt flag
			 ///--------------------------------------------///
			 CLR_BIT(P2_INT, (1<<6));  //clear P2_6 interrupt 
 	 }
	 else
 	 {
 	    ///--------------------------------------------///
		  /// Clear interrupt flag
		  ///--------------------------------------------///
	    WRITE_REG16(P2_INT, 0x0000);  //clear all P2_n interrupt if other cse
 	 }
}
#endif

#ifdef FEATURE_ZET7101_CUSTOMER_TIMER2_ISR
void CustomerTimer2Init(WORD wTimerPeriod)
{
  U4 data dwTimerPeriod;

  //GPIO output case
	SET_BIT(AD_CTRL14,1<<3);	// TR10 ==> P2_3 Pin(1)
	SET_BIT(P2_SEL18,1<<3);  // P2_3 as  1.8V(1) 				  
  SET_BIT(P2,1<<3); /// P2_3 High (1)			
	SET_BIT(IODIR_P2,1<<3);/// P2_3 as output(1)		

  ///------------------------------------------------///
  /// Reset Timer
  ///------------------------------------------------///
	CLR_BIT(REG32_TCON2, TMR_EN);   //stop timer
  CLR_BIT(REG32_TMR2_IF, TMR_IF); //clear Interrupt flag
  SET_BIT(REG32_TCON2, TMR_RST);  //reset timer count
  CLR_BIT(REG32_TCON2, TMR_RST);  

  ///------------------------------------------------///
  /// Set Timer Period
  ///------------------------------------------------///
  dwTimerPeriod = (wTimerPeriod * RC512K_TRIM_REFERENCE) / ZetVar2.bTimerTrimCounter;
  dwTimerPeriod = 0 - dwTimerPeriod;
  WRITE_REG(REG32_TCON2, TMR_RELOAD);  //reload enable when timer expire

	CLR_BIT(REG32_TCON2, TCLK_SEL); //switch to fast clock
	while((READ_REG(REG_TMR2_32M_STABLE) & TMR_STABLE) !=TMR_STABLE);
	
	WRITE_REG32(REG32_TMR2, dwTimerPeriod); //set timer period value
	SET_BIT(REG32_TCON2, TCLK_SEL);				//switch back to slow clock
	while((READ_REG(REG_TMR2_40K_STABLE) & TMR_STABLE) !=TMR_STABLE);
	
	SET_BIT(REG32_TCON2, TMR_EN); //start timer	
}

void CustomerTimer2Isr()
{
  if((CustomerVar.bToggleCnt%2)==0)
	{
     SET_BIT(P2,1<<3); /// P2_3 High (1)		
	}
	else
	{
     CLR_BIT(P2,1<<3); /// P2_3 low (0)		
	}
	
	CustomerVar.bToggleCnt=(CustomerVar.bToggleCnt%2)+1;
	CLR_BIT(REG32_TMR2_IF, TMR_IF);
}
#endif

#ifdef FEATURE_IR_SCAN
void IRInit(void)
{	
  /// IR_EN as output High
	SET_BIT(P2,1<<0);  ///ir_en, set low TR7
	SET_BIT(IODIR_P2,1<<0);  ///ir_en, set output TR7
	SET_BIT(AD_CTRL14,1<<0); // ir_en DIO en, TR7
#ifdef FEATURE_IR_BASE
 	sIRScan.bIRBaseRound = 1;
#endif	
}

void IRSetup( unsigned char freq_multi, unsigned char sqrt_mode,
             unsigned char rx_sine_len)
{
	U1	bk_pn_num;
	U4	bk_REG32_RX_PN_CODE_OUT0;
	U4	bk_REG32_SINE_ROM_LEN_RX;
	U4	bk_REG32_TX_PN_CODE;
	U4	bk_REG32_RX_HOLD_CYCE_ADDR;
	U4	bk_REG32_LPF_COEFF_HALF_LEN;
	U1	bk_TXSIN_NUM;
	U4	bk_REG32_RX_FREQ_MULTIPLEA;
	U4	bk_REG32_SINE_FREQ_SCALE;
	U4	bk_REG32_FRONT_ADC_RST_CNT;
	U4	bk_REG16_CHIP_2_CHIP_DURA;
	U1	bk_REG32_VREF6V;
	U1	bk_REG32_TX_CTRL_1_;
	U1	bk_REG32_DAC_CTRL2_1_;
	U1	bk_REG32_VREF3V;
	U1	bk_REG32_PN_CTRL;

	sIRScan.bIR_ADmode = 1;

	SET_BIT(REG32_PN_CTRL, RG_AMP_FUNC_AUTO_EN);	

	///// 	adc mode
	SET_BIT(REG32_AD_CTRL10,1<<5);	 
	SET_BIT(REG32_AD_CTRL10,1<<4); 

	bk_pn_num = READ_REG(REG32_TRY_PNCNT+2);
	bk_REG32_RX_PN_CODE_OUT0 = READ_REG32(REG32_RX_PN_CODE_OUT0);
	bk_REG32_SINE_ROM_LEN_RX = READ_REG32(REG32_SINE_ROM_LEN_RX);
	bk_REG32_TX_PN_CODE = READ_REG32(REG32_TX_PN_CODE);
	bk_REG32_RX_HOLD_CYCE_ADDR = READ_REG32(REG32_RX_HOLD_CYCE_ADDR);
	bk_REG32_LPF_COEFF_HALF_LEN = READ_REG32(REG32_LPF_COEFF_HALF_LEN);
	bk_TXSIN_NUM = READ_REG(REG32_TRY_PNCNT);
	bk_REG32_RX_FREQ_MULTIPLEA = READ_REG32(REG32_RX_FREQ_MULTIPLEA);
	bk_REG32_SINE_FREQ_SCALE = READ_REG32(REG32_SINE_FREQ_SCALE);
	bk_REG32_FRONT_ADC_RST_CNT = READ_REG32(REG32_FRONT_ADC_RST_CNT);
	bk_REG16_CHIP_2_CHIP_DURA = READ_REG32(REG16_CHIP_2_CHIP_DURA);
	bk_REG32_VREF6V =  READ_REG(REG32_VREF6V);
	bk_REG32_TX_CTRL_1_ =  READ_REG(REG32_TX_CTRL+1);
	bk_REG32_DAC_CTRL2_1_ = READ_REG(REG32_DAC_CTRL2+1);
	bk_REG32_VREF3V 	= READ_REG(REG32_VREF3V);
	bk_REG32_PN_CTRL	= READ_REG(REG32_PN_CTRL);

#ifdef FEATURE_IR_BASE
	if( sIRScan.bIRBaseRound == 1 )
	{
		//// set ir_out pin as No-Signal			set drive-pin to TR53(NULL-pin)
		WRITE_REG(REG32_TRNUM_OUT0, 0x35);
	}
	else
	{
		//// set ir_out pin as TX 						set drive-pin to TR6
		WRITE_REG(REG32_TRNUM_OUT0, 0x06);
	}
#else
	//// set ir_out pin as TX 							set drive-pin to TR6
	WRITE_REG(REG32_TRNUM_OUT0, 0x06);
#endif

	/// ir_in as ADC0
	PAD_SEL[14] = 0x10;

	/////////////////  PN Num = 1
	WRITE_REG(REG32_TRY_PNCNT+2, 1); 

	/*
	//// TX square	mode 0: srqt	1: dac mode
	if(sqrt_mode==0x01){
	CLR_BIT(REG_STR_PN_CTRL_1, 1<<0);
	}else{
	SET_BIT(REG_STR_PN_CTRL_1, 1<<0);
	}
	*/

	///// 	PN code
	WRITE_REG32(REG32_RX_PN_CODE_OUT0, 0x00000001); 
	WRITE_REG32(REG32_TX_PN_CODE, 0x00000001); 

	////
	WRITE_REG32(REG32_RX_HOLD_CYCE_ADDR,0x03); 

	WRITE_REG32(REG32_SINE_ROM_LEN_RX,rx_sine_len);  /// RX SINE ROM Length

	WRITE_REG32(REG32_LPF_COEFF_HALF_LEN,(rx_sine_len*2)-1); // 	coeff len =( 2* tx_sine_len  ) -1
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////  bit6-0: Tone1 Sine Num / Bit14-8: Tone2 Sine num / bit21-16: chip-num / bit23:dual or sigle Tone  /bit22: NA/////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	WRITE_REG(REG32_PN_CTRL,(bk_REG32_PN_CTRL & 0x8F) | 0x10);
	
	WRITE_REG(REG32_TRY_PNCNT, freq_multi+1);  ///usually TX sine num > fre_multi, maybe morethan 1 ....OK	 

	WRITE_REG32(REG32_RX_FREQ_MULTIPLEA,freq_multi); // multiple frequence //Jason_0902 OSR800

	/////////////////////////////////////////////////////////////////////////////////
	//////////	 SINE_FREQ_SCALE	///////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
	//	bit Tone A frequence multiple
	//	bit Tone B frequence multiple
	//	bit 27-16, TX Base frequence ROM length
	//
	//////////////////////////////////////////////////////////////////////////////
	WRITE_REG32(REG32_SINE_FREQ_SCALE,(0xffff0000 &(rx_sine_len<<19))| (0xffff&freq_multi)); //tx len = 4*rx_sine_len

	///ADC_FRONT_RST
	WRITE_REG32(REG32_FRONT_ADC_RST_CNT,0x002e002e); // adc front  rst 

	///////////////////////////////////////////////////////////////////////
	//				
	//	 .RG_CHIP_2_CHIP_DURA( {PN_DURCNT1_OUT,PN_DURCNT0_OUT}),
	//	 tx chip to chip delay, for TX vcm settle
	//
	//	 .RG_FRM_2_FRM_DURA(	{PN_DURCNT3_OUT,PN_DURCNT2_OUT}),
	//	 tx delay time before first chip start,  for TX vcm settle
	//
	//////////////////////////////////////////////////////////////////////////
	WRITE_REG32(REG16_CHIP_2_CHIP_DURA,0x00300030);

	SET_BIT(REG32_VREF6V, 1<<4);

	////TX gain down
	WRITE_REG(REG32_TX_CTRL+1,0x00);

	WRITE_REG(REG32_DAC_CTRL2+1,0x00);

	///vcm bias to 1.2
	CLR_BIT(REG32_VREF3V, 1<<1);
	CLR_BIT(REG32_VREF3V, 1<<0);

	sIRScan.bIR_ADmode_INT = 0;

	//////	 modem scan
	SET_BIT(REG_STR_PN_CTRL_2,1<<0);

	/////  while finish
	while(sIRScan.bIR_ADmode_INT == 0)
	{
		SET_BIT(REG32_VREF6V, 1<<4);
	}

	sIRScan.bIR_ADmode_INT = 0;

	/////////////////  PN Num = 1
	WRITE_REG(REG32_TRY_PNCNT+2, bk_pn_num); 
	///// 	PN code
	WRITE_REG32(REG32_RX_PN_CODE_OUT0, bk_REG32_RX_PN_CODE_OUT0); 
	WRITE_REG32(REG32_TX_PN_CODE, bk_REG32_TX_PN_CODE); 

	////
	WRITE_REG32(REG32_RX_HOLD_CYCE_ADDR,bk_REG32_RX_HOLD_CYCE_ADDR); 

	WRITE_REG32(REG32_SINE_ROM_LEN_RX,bk_REG32_SINE_ROM_LEN_RX);	/// RX SINE ROM Length

	WRITE_REG32(REG32_LPF_COEFF_HALF_LEN,bk_REG32_LPF_COEFF_HALF_LEN); // 	coeff len =( 2* tx_sine_len  ) -1

	WRITE_REG(REG32_TRY_PNCNT,bk_TXSIN_NUM);	///usually TX sine num > fre_multi, maybe morethan 1 ....OK 	

	WRITE_REG32(REG32_RX_FREQ_MULTIPLEA,bk_REG32_RX_FREQ_MULTIPLEA); // multiple frequence //Jason_0902 OSR800

	WRITE_REG32(REG32_SINE_FREQ_SCALE,bk_REG32_SINE_FREQ_SCALE); //tx len = 4*rx_sine_len

	///ADC_FRONT_RST
	WRITE_REG32(REG32_FRONT_ADC_RST_CNT,bk_REG32_FRONT_ADC_RST_CNT); // adc front  rst 

	WRITE_REG32(REG16_CHIP_2_CHIP_DURA,bk_REG16_CHIP_2_CHIP_DURA);

	WRITE_REG(REG32_VREF6V, bk_REG32_VREF6V);

	WRITE_REG(REG32_TX_CTRL+1, bk_REG32_TX_CTRL_1_);

	WRITE_REG(REG32_DAC_CTRL2+1, bk_REG32_DAC_CTRL2_1_);

	WRITE_REG(REG32_VREF3V, bk_REG32_VREF3V);

	WRITE_REG(REG32_PN_CTRL,bk_REG32_PN_CTRL);

	CLR_BIT(REG32_PN_CTRL, RG_AMP_FUNC_AUTO_EN);	

	/// ir_in as gnd
	PAD_SEL[14] = 0x00;

	/////  back to normal mode
	CLR_BIT(REG32_AD_CTRL10,1<<5);	 
	SET_BIT(REG32_AD_CTRL10,1<<4); 
}

void TaskIRScan(void)
{
	MSMutualScanAnalogSetup();
	ADCPowerOn(CAP_MODE);
	IRSetup(40,0,100);
	ADCPowerOff(CAP_MODE);
}
#endif

#ifdef FEATURE_SELF_SCAN
void TaskSelfScan(void)
{
	CLR_BIT(REG32_PN_DEMOD_IF,1<<0);
	IntAdcEnable();
	MSMutualScanAnalogSetup();
	ADCPowerOn(CAP_MODE);
#ifdef FEATURE_NEW_MUTUAL	
	for(sSelfScan.bSensorIdx=0; sSelfScan.bSensorIdx < SELF_TRACE; sSelfScan.bSensorIdx++)
	{
		MSMutualScanStart();
	}
#else
	MSSelfScanStart();
#endif
	ADCPowerOff(CAP_MODE);
	IntAdcDisable();

#ifdef FEATURE_SELF_SCAN_BASE_TRACKING
	BYTE i = 0;
	sSelfScan.wForceValue = 0;
	for(i=0; i < SELF_TRACE; i++)
	{
		sSelfScan.wForceValue += ABSDIFF(sSelfScan.wSelfValue[i], sSelfScan.sSelfBase[i]);

		//-------------------------------------------// 
		// Base Tracking	
		//-------------------------------------------// 	 
		if(ZetVar.bCalibrationCtrl & BASE_EN_TRACKINGBASE) 
		{ 
			if(sSelfScan.bSelfCounter > 4) 
			{ 
				short sBaseTrackStepMax = (short)ZetDF.cAlgoPage.scAlgoData.bForceBaseTrackMaxStep; 
				short sBaseTrackStepMin = (short)ZetDF.cAlgoPage.scAlgoData.bForceBaseTrackMinStep; 
				short sADBaseDelta = sSelfScan.wSelfValue[i] - sSelfScan.sSelfBase[i]; 
				short sBaseTrackScale = 0; 

				if(sADBaseDelta > sBaseTrackStepMax) 
				{ 
					sBaseTrackScale = sBaseTrackStepMax; 
				} 
				else if(sADBaseDelta < (-1*sBaseTrackStepMax)) 
				{ 
					sBaseTrackScale = (-1*sBaseTrackStepMax); 
				} 
				else if((sADBaseDelta < sBaseTrackStepMin) &&  (sADBaseDelta > (-1*sBaseTrackStepMin))) 
				{ 
					sBaseTrackScale = 0; 
				} 
				else 
				{ 
					sBaseTrackScale = sADBaseDelta; 
				} 
				sSelfScan.sSelfBase[i] += sBaseTrackScale; 
			} 
			else if(sSelfScan.bSelfCounter < 4) 
			{ 	
					sSelfScan.sSelfBase[i] += sSelfScan.wSelfValue[i]; 
			} 
			else	// (sSelfScan.bSelfCounter == 4) 
			{
				sSelfScan.sSelfBase[i] = sSelfScan.sSelfBase[i] >> 2; 
			}  
		}
	}

	if(sSelfScan.bSelfCounter < 5)
	{
		sSelfScan.bSelfCounter ++;
	}
	sSelfScan.wForceValue /= SELF_TRACE;
#endif 	
}

#ifdef FEATURE_NEW_MUTUAL
void MSMutualScanStart(void)
{
	U1    bk_pn_num;
	U4    bk_REG32_RX_PN_CODE_OUT0;
	U1    bk_REG32_AD_CTRL10;
	U1    bk_REG32_DAC_CTRL0;
	U1    bk_REG32_TX_CTRL;
	U1    bk_REG32_TX_BUF;
	U1    bk_REG32_VREF6V;
	U1    bk_REG32_AD_CTRL13;
	U1    bk_REG32_STR_PN_CTRL_1;
	U1    bk_REG32_PN_CTRL_2;
	U1    bk_REG32_SELF_CTRL;
	U1		bk_REG32_PN_CTRL;

	/////  set Self mode scan flag
	sSelfScan.bSelfMode= 1;

	SET_BIT(REG32_PN_CTRL, RG_AMP_FUNC_AUTO_EN);	

	/// TX manual mode,  disable TX auto config
	SET_BIT(REG32_STR_PN_CTRL,RG_MANUAL);

	//////////////////////////////////////////////
	/// Back up parameters
	//////////////////////////////////////////////
	bk_pn_num = READ_REG(REG32_TRY_PNCNT+2);
	bk_REG32_AD_CTRL10 = READ_REG(REG32_AD_CTRL10);
	bk_REG32_DAC_CTRL0= READ_REG(REG32_DAC_CTRL0);
	bk_REG32_TX_CTRL= READ_REG(REG32_TX_CTRL);
	bk_REG32_TX_BUF= READ_REG(REG32_TX_BUF);
	bk_REG32_AD_CTRL13= READ_REG(REG32_AD_CTRL13);
	bk_REG32_VREF6V =  READ_REG(REG32_VREF6V);
	bk_REG32_STR_PN_CTRL_1 =   READ_REG(REG32_STR_PN_CTRL+1);
	bk_REG32_PN_CTRL_2 = READ_REG(REG32_PN_CTRL+2);
	bk_REG32_RX_PN_CODE_OUT0 = READ_REG32(REG32_RX_PN_CODE_OUT0);
	bk_REG32_SELF_CTRL  = READ_REG(REG32_SELF_CTRL);
	bk_REG32_PN_CTRL = READ_REG(REG32_PN_CTRL);

	/////////////////////////////////
	/////   Self Scan Setup       //////////
	/////////////////////////////////

	/////////////////  PN Num = 1
	//WRITE_REG(REG32_TRY_PNCNT+2, 1); 
	WRITE_REG(REG32_TRY_PNCNT+2, 2); 
	//WRITE_REG(REG32_PN_CTRL,READ_REG(REG32_PN_CTRL)&0x8f);

	// pwd  RG_RX_PWREF_EN_15V
	SET_BIT(REG32_AD_CTRL10,1<<6);   

	// RG_RX_FRONT_MODE_15V  01: scaling mode 
	CLR_BIT(REG32_AD_CTRL10,1<<5);   
	SET_BIT(REG32_AD_CTRL10,1<<4);   

	// pwd  RG_DAC0_PWD_15V
	CLR_BIT(REG32_DAC_CTRL0,1<<0);   

	// pwd  RG_TX_LPF0_PWD_15V
	SET_BIT(REG32_TX_CTRL,1<<0);  

	// pwd  RG_TXBUF0_PWD_15V
	SET_BIT(REG32_TX_BUF,1<<0);  

	// pwd  RG_VREF6V_PWD_15V
	SET_BIT(REG32_VREF6V,1<<3);  

	// on  RG_DAC6V_ENE_15V
	CLR_BIT(REG32_AD_CTRL13,1<<1);  

	// on RG_DACS_PWD_15V
	CLR_BIT(REG32_AD_CTRL13,1<<4);  

	//// DAC square mode
	CLR_BIT(REG32_STR_PN_CTRL+1,1<<0); 

	////  str_pn_d,   sync DAC_CLK
	SET_BIT(REG32_PN_CTRL+2,1<<4);

	//// DA_SELF_CK divider
	//SET_BIT(SELF_CTRL,1<<5); 
	SET_BIT(REG32_SELF_CTRL,1<<4); 

	/////   PN code
	WRITE_REG32(REG32_RX_PN_CODE_OUT0, 0x00000001); 
	
	////  SET TX as SYNC PAD 
	//SET_BIT(REG32_SELF_CTRL+1,1<<4);  

	//////////////////////////////////////////////
	/////   Self   PAD/Cannnel    Configration   //////////
	//////////////////////////////////////////////
	/*
		///example    TR4  connect to ADC0
		PAD_SEL[4] = 0x10;
		///example    TR5  connect to ADC1
		PAD_SEL[5] = 0x11;
	*/

	if(sSelfScan.bSensorIdx==0){
		PAD_SEL[48] = 0x02;  
		PAD_SEL[49] = 0x02; 
		PAD_SEL[50] = 0x02;  
		PAD_SEL[51] = 0x10; 
	}else if(sSelfScan.bSensorIdx==1){
		PAD_SEL[48] = 0x02;  
		PAD_SEL[49] = 0x02; 
		PAD_SEL[50] = 0x10;  
		PAD_SEL[51] = 0x02; 
	}else if(sSelfScan.bSensorIdx==2){
		PAD_SEL[48] = 0x02;  
		PAD_SEL[49] = 0x10; 
		PAD_SEL[50] = 0x02;  
		PAD_SEL[51] = 0x02; 
	}else if(sSelfScan.bSensorIdx==3){
		PAD_SEL[48] = 0x10;  
		PAD_SEL[49] = 0x02; 
		PAD_SEL[50] = 0x02;  
		PAD_SEL[51] = 0x02; 
	}
	//PAD_SEL[2] = 0x12; //0x02;
	//PAD_SEL[3] = 0x13; //0x02;
	//CLR_BIT(REG32_STR_PN_CTRL,RG_MODEM_POWER_DOWN);
	//SET_BIT(REG32_AD_CTRL13,1<<1);
	//SET_BIT(REG32_AD_CTRL13,1<<0);

	//////////////////////////////////////////////
	/////   Self   Scan Start                           //////////
	//////////////////////////////////////////////
	//////   modem scan (self scan start)
	SET_BIT(REG_STR_PN_CTRL_2,1<<0);
	////  set interrupt flag = 0
	sSelfScan.bSelfModeINT = 0;

	/////  while finish
	while(sSelfScan.bSelfModeINT== 0);

	sSelfScan.bSelfModeINT = 0;

	PAD_SEL[48] = 0x00; //0x02;
	PAD_SEL[49] = 0x00; //0x02;
	PAD_SEL[50] = 0x00; //0x02;
	PAD_SEL[51] = 0x00; //0x02;	

	//////////////////////////////////////////////
	////// restore parameters
	//////////////////////////////////////////////
	WRITE_REG(REG32_TRY_PNCNT+2, bk_pn_num); 
	/////   PN code
	WRITE_REG32(REG32_RX_PN_CODE_OUT0, bk_REG32_RX_PN_CODE_OUT0); 

	WRITE_REG(REG32_AD_CTRL10, bk_REG32_AD_CTRL10);
	WRITE_REG(REG32_DAC_CTRL0, bk_REG32_DAC_CTRL0);
	WRITE_REG(REG32_TX_CTRL, bk_REG32_TX_CTRL);
	WRITE_REG(REG32_TX_BUF, bk_REG32_TX_BUF);
	WRITE_REG(REG32_AD_CTRL13, bk_REG32_AD_CTRL13);
	WRITE_REG(REG32_VREF6V, bk_REG32_VREF6V);
	WRITE_REG(REG32_STR_PN_CTRL+1, bk_REG32_STR_PN_CTRL_1);
	WRITE_REG(REG32_PN_CTRL+2, bk_REG32_PN_CTRL_2);
	WRITE_REG(REG32_PN_CTRL, bk_REG32_PN_CTRL);

	WRITE_REG(REG32_SELF_CTRL, bk_REG32_SELF_CTRL);

	///by pass decorr
	//CLR_BIT(REG32_PN_CTRL+1, 1<<1);   ///

	/// TX manual mode,  disable TX auto config
	CLR_BIT(REG32_STR_PN_CTRL,RG_MANUAL);

	CLR_BIT(REG32_PN_CTRL, RG_AMP_FUNC_AUTO_EN);	
}

#else

void MSSelfScanStart(void)
{
	U1		bk_pn_num;
	U4		bk_REG32_RX_PN_CODE_OUT0;
	U1		bk_REG32_AD_CTRL10;
	U1		bk_REG32_DAC_CTRL0;
	U1		bk_REG32_TX_CTRL;
	U1		bk_REG32_TX_BUF;
	U1		bk_REG32_VREF6V;
	U1		bk_REG32_AD_CTRL13;
	U1		bk_REG32_STR_PN_CTRL_1;
	U1		bk_REG32_PN_CTRL_2;
	U1		bk_REG32_SELF_CTRL;
	U1		bk_REG32_PN_CTRL;

	////Jason 0905
	U4		bk_REG32_SINE_ROM_LEN_RX;
	U4		bk_REG32_RX_FREQ_MULTIPLEA;
	U4		bk_REG32_SINE_FREQ_SCALE;
	U1		bk_TXSIN_NUM; 
	
	/////  set Self mode scan flag
	sSelfScan.bSelfMode= 1;

	SET_BIT(REG32_PN_CTRL, RG_AMP_FUNC_AUTO_EN);	

	/// TX manual mode,  disable TX auto config
	SET_BIT(REG32_STR_PN_CTRL,RG_MANUAL);

	//////////////////////////////////////////////
	/// Back up parameters
	//////////////////////////////////////////////
	bk_pn_num = READ_REG(REG32_TRY_PNCNT+2);
	bk_REG32_AD_CTRL10 = READ_REG(REG32_AD_CTRL10);
	bk_REG32_DAC_CTRL0= READ_REG(REG32_DAC_CTRL0);
	bk_REG32_TX_CTRL= READ_REG(REG32_TX_CTRL);
	bk_REG32_TX_BUF= READ_REG(REG32_TX_BUF);
	bk_REG32_AD_CTRL13= READ_REG(REG32_AD_CTRL13);
	bk_REG32_VREF6V =  READ_REG(REG32_VREF6V);
	bk_REG32_STR_PN_CTRL_1 =	 READ_REG(REG32_STR_PN_CTRL+1);
	bk_REG32_PN_CTRL_2 = READ_REG(REG32_PN_CTRL+2);
	bk_REG32_RX_PN_CODE_OUT0 = READ_REG32(REG32_RX_PN_CODE_OUT0);
	bk_REG32_SELF_CTRL	= READ_REG(REG32_SELF_CTRL);
	bk_REG32_PN_CTRL = READ_REG(REG32_PN_CTRL);

	////Jason 0905
	bk_REG32_SINE_ROM_LEN_RX = READ_REG32(REG32_SINE_ROM_LEN_RX);
	bk_REG32_RX_FREQ_MULTIPLEA = READ_REG32(REG32_RX_FREQ_MULTIPLEA); 
	bk_REG32_SINE_FREQ_SCALE = READ_REG32(REG32_SINE_FREQ_SCALE);
	bk_TXSIN_NUM = READ_REG(REG32_TRY_PNCNT);

	/////////////////////////////////
	///// 	Self Scan Setup 			//////////
	/////////////////////////////////

	/////////////////  PN Num = 1
	//WRITE_REG(REG32_TRY_PNCNT+2, 1); 
	WRITE_REG(REG32_TRY_PNCNT+2, 2); 
	WRITE_REG(REG32_PN_CTRL,READ_REG(REG32_PN_CTRL)&0x8f);

	// pwd	RG_RX_PWREF_EN_15V
	SET_BIT(REG32_AD_CTRL10,1<<6);	 

	// RG_RX_FRONT_MODE_15V  00: self mode 
	CLR_BIT(REG32_AD_CTRL10,1<<5);	 
	CLR_BIT(REG32_AD_CTRL10,1<<4);	 

	// pwd	RG_DAC0_PWD_15V
	SET_BIT(REG32_DAC_CTRL0,1<<0);	 

	// pwd	RG_TX_LPF0_PWD_15V
	SET_BIT(REG32_TX_CTRL,1<<0);	

	// pwd	RG_TXBUF0_PWD_15V
	SET_BIT(REG32_TX_BUF,1<<0);  

	// pwd	RG_VREF6V_PWD_15V
	SET_BIT(REG32_VREF6V,1<<3);  

	// on  RG_DAC6V_ENE_15V
	CLR_BIT(REG32_AD_CTRL13,1<<1);	

	// on RG_DACS_PWD_15V
	CLR_BIT(REG32_AD_CTRL13,1<<4);	

	//// DAC square mode
	CLR_BIT(REG32_STR_PN_CTRL+1,1<<0); 

	////	str_pn_d, 	sync DAC_CLK
	SET_BIT(REG32_PN_CTRL+2,1<<4);

	//// DA_SELF_CK divider
	//SET_BIT(SELF_CTRL,1<<5); 
	SET_BIT(REG32_SELF_CTRL,1<<4); 

	///// 	PN code
	WRITE_REG32(REG32_RX_PN_CODE_OUT0, 0x00000001); 
	////	SET TX as SYNC PAD 
	SET_BIT(REG32_SELF_CTRL+1,1<<4);

	////Jason 0905
	WRITE_REG32(REG32_RX_FREQ_MULTIPLEA,bk_REG32_SINE_ROM_LEN_RX); //RX  multiple frequence to MAX	
	WRITE_REG(REG32_TRY_PNCNT, bk_REG32_SINE_ROM_LEN_RX+1); 	///TX SINE NUM	 MAX+1	
	
	WRITE_REG(REG8_TX_SINE_FREQSCALE_GRP_A,bk_REG32_SINE_ROM_LEN_RX); 	// TX multipule frequence to MAX

	//////////////////////////////////////////////
	///// 	Self	 PAD/Cannnel		Configration	 //////////
	//////////////////////////////////////////////
	/*
		///example		TR4  connect to ADC0
		PAD_SEL[4] = 0x10;
		///example		TR5  connect to ADC1
		PAD_SEL[5] = 0x11;
	*/

	//Jason 0905
	PAD_SEL[49] = 0x10; //0x02;
	PAD_SEL[51] = 0x00; //0x02;

	//SET_BIT(REG32_AD_CTRL13,1<<1);
	//SET_BIT(REG32_AD_CTRL13,1<<0);

	//////////////////////////////////////////////
	///// 	Self	 Scan Start 													//////////
	//////////////////////////////////////////////

	////	set interrupt flag = 0
	sSelfScan.bSelfModeINT = 0;

	//////	 modem scan (self scan start)
	SET_BIT(REG_STR_PN_CTRL_2,1<<0);

	/////  while finish
	while(sSelfScan.bSelfModeINT== 0);

	sSelfScan.bSelfModeINT = 0;

	PAD_SEL[49] = 0x00;
	PAD_SEL[51] = 0x00;

	//////////////////////////////////////////////
	////// restore parameters
	//////////////////////////////////////////////
	WRITE_REG(REG32_TRY_PNCNT+2, bk_pn_num); 
	///// 	PN code
	WRITE_REG32(REG32_RX_PN_CODE_OUT0, bk_REG32_RX_PN_CODE_OUT0); 

	WRITE_REG(REG32_AD_CTRL10, bk_REG32_AD_CTRL10);
	WRITE_REG(REG32_DAC_CTRL0, bk_REG32_DAC_CTRL0);
	WRITE_REG(REG32_TX_CTRL, bk_REG32_TX_CTRL);
	WRITE_REG(REG32_TX_BUF, bk_REG32_TX_BUF);
	WRITE_REG(REG32_AD_CTRL13, bk_REG32_AD_CTRL13);
	WRITE_REG(REG32_VREF6V, bk_REG32_VREF6V);
	WRITE_REG(REG32_STR_PN_CTRL+1, bk_REG32_STR_PN_CTRL_1);
	WRITE_REG(REG32_PN_CTRL+2, bk_REG32_PN_CTRL_2);
	WRITE_REG(REG32_PN_CTRL, bk_REG32_PN_CTRL);

	WRITE_REG(REG32_SELF_CTRL, bk_REG32_SELF_CTRL);

	////Jason 0905
	WRITE_REG(REG32_TRY_PNCNT,bk_TXSIN_NUM);  
	WRITE_REG32(REG32_SINE_FREQ_SCALE,bk_REG32_SINE_FREQ_SCALE); // len = 4*rx_sine_len
	WRITE_REG32(REG32_RX_FREQ_MULTIPLEA,bk_REG32_RX_FREQ_MULTIPLEA); // multiple frequence 

	///by pass decorr
	//CLR_BIT(REG32_PN_CTRL+1, 1<<1); 	///

	/// TX manual mode,  disable TX auto config
	CLR_BIT(REG32_STR_PN_CTRL,RG_MANUAL);

	CLR_BIT(REG32_PN_CTRL, RG_AMP_FUNC_AUTO_EN);	
}
#endif	// FEATURE_NEW_MUTUAL
#endif	// FEATURE_SELF_SCAN

#ifdef FEATURE_CUSTOMER_PROTOCOL

CustomerVarType xdata CustomerVar;
void CustomerDebug(void)
{
	if(ZetVar.bWorkingState != WORKING_STATE_ZET_CMD_STATE)
	{
		return;
	}

	#ifdef FEATURE_SELF_SCAN_DEBUG
	AlgorithmDataPtr->sDev[0][5] = sSelfScan.wSelfValue[0];
	#endif
}

void CustomerDataFormat(void)
{
 //Fill coordinate information to Double buffer
	BYTE data i;
	BYTE data bPacketNumber = 0;
	BYTE data bCNT = 0;
	BYTE data bFingerNum = ZetDF.cFormatCtrl.scDataCtrl.bFingerNum;
	WORD data wValidPoint = 0;
	WORD data wPosX;
	WORD data wPosY;
	BYTE xdata bLeaveStatus =0;
	BYTE xdata bReportPoint =0;
	PointType xdata ptReportPoint;

	if(ZetVar.bWorkingState!=WORKING_STATE_CUSTOMER_NORMAL)
	{
		return;
	}

	// Check finger status
	for(i=0;i<bFingerNum; i++)
	{
		if((ZetVar2.FingerCoordinateRecord[i].bFingerDown == FINGER_DOWN)
			&&	((!(ZetVar2.FingerCoordinateRecord[i].wFingerStatus & FINGER_STATUS_FORCE_NO_FINGER_CHECK)) || (ZetVar.bLcdOn == 0))) // dont check force no finger when LCD off
		{
			bCNT++;
			wValidPoint |= 0x0001<< i;
		}
		else if(((CustomerVar.wCustomerLastValidPoint>>i)&0x0001)==0x0001)
		{
			ZetVar2.FingerCoordinateRecord[i].bFingerDown 	= FINGER_UP;
		}
	} 			

	// Change Timer
	if(wValidPoint > 0)
	{
		ZetVar.wSysMode2 |= SYS_MODE2_RED_MODE;

		ZetVar2.wGreenModeCounter = 0;
		if(ZetVar.wSysMode2 & SYS_MODE2_GREEN_MODE)
		{
			ZetVar.wSysMode2 &= ~SYS_MODE2_GREEN_MODE;
		}
		else if(ZetVar.wSysMode2 & SYS_MODE2_YELLOW_MODE)
		{
			ZetVar.wSysMode2 &= ~SYS_MODE2_YELLOW_MODE;
			ZetVar2.bTimerCounter = ZetDF.cAlgoPage.scAlgoPowerSave.bGreenModeDebounce;
		}

		if(ZetVar2.bTimerCounter > 0)
		{
			ZetVar2.bTimerCounter --;
		}
	}
	else
	{
		ZetVar.wSysMode2 &= ~SYS_MODE2_RED_MODE;
	}

	CustomerVar.bDoubleBufferStoreIdx=((CustomerVar.bDoubleBufferStoreIdx+1)%2);

	// Fill buffer
	if((CustomerVar.bCustomerLastReportFingerCNT>0)||(bCNT>0))
	{ 
		CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][0]=bCNT;

		for(i=0;i<bFingerNum; i++)
		{
			if(((wValidPoint>>i)&0x0001)==0x0001)
			{
				if(ZetDF.cAlgoPage.scSmoothCtrl.bTimeSmoothEnable == TRUE)
				{
					CoorExePointGet(i, COOR_EXE_IDX_LAST2, &ptReportPoint);
				}
				else
				{
					ptReportPoint.x = ZetVar2.FingerCoordinateRecord[i].ptCoordinate.x;
					ptReportPoint.y = ZetVar2.FingerCoordinateRecord[i].ptCoordinate.y;
				}

				//also need to check Coord. changed!		 
				if(ZetDF.cFormatCtrl.scDataCtrl.bXYCoorExchange == TRUE)
				{
					wPosX = ptReportPoint.y;
					wPosY = ptReportPoint.x;
				}
				else
				{
					wPosX = ptReportPoint.x;
					wPosY = ptReportPoint.y;
				}

				CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][3+bPacketNumber*7] = (BYTE)(((wPosX>>8)&0x000F)<<4); 
				CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][4+bPacketNumber*7] = (BYTE)(wPosX&0x00FF);
				CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][5+bPacketNumber*7] = (BYTE)(((wPosY>>8)&0x000F)<<4); 
				CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][6+bPacketNumber*7] = (BYTE)(wPosY&0x00FF); 				
				CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][7+bPacketNumber*7] = 0x10;
				CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][8+bPacketNumber*7] = 0;

				bReportPoint |= 0x0001<< i;

				if(CustomerVar.bCustomReportCnt!=0xFF) 
				{
					CustomerVar.bCustomReportCnt++;
				} 
				else 
				{
					CustomerVar.bCustomReportCnt=0;
				} 
				bPacketNumber++;				
			}
			else if(((wValidPoint>>i)&0x0001)==0x0000)
			{ 	 
				if(((CustomerVar.wCustomerLastValidPoint>>i)&0x0001)==0x0001) // Finger UP
				{
					if(CustomerVar.bCustomerLastReportPoint == 0)
					{
						WORD data wDiff;
						DeltaDistanceGet(i,DISTANCE_IDX_NEW, &wDiff);
						CoorRawPointGet(i, COOR_EXE_IDX_LAST, &ptReportPoint);
						if(((ptReportPoint.x > 50) &&  
							 (ptReportPoint.x < (ZetDF.cGlobalData.scPanelInformation.wSenAxisRes - 50)) &&
							 (ptReportPoint.y > 50) &&	
							 (ptReportPoint.y < (ZetDF.cGlobalData.scPanelInformation.wDriAxisRes - 50))) || (wDiff < 30))
						{
							CoorExePointGet(i, COOR_EXE_IDX_LAST, &ptReportPoint);
						}
						//also need to check Coord. changed!		 
						if(ZetDF.cFormatCtrl.scDataCtrl.bXYCoorExchange == TRUE)
						{
							wPosX = ptReportPoint.y;//ZetVar2.FingerCoordinateRecord[i].ptCoordinate.y;
							wPosY = ptReportPoint.x;//ZetVar2.FingerCoordinateRecord[i].ptCoordinate.x;
						}
						else
						{
							wPosX = ptReportPoint.x;//ZetVar2.FingerCoordinateRecord[i].ptCoordinate.x;
							wPosY = ptReportPoint.y;//ZetVar2.FingerCoordinateRecord[i].ptCoordinate.y;
						}
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][3+bPacketNumber*7] = (BYTE)(((wPosX>>8)&0x000F)<<4); 
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][4+bPacketNumber*7] = (BYTE)(wPosX&0x00FF);
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][5+bPacketNumber*7] = (BYTE)(((wPosY>>8)&0x000F)<<4); 
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][6+bPacketNumber*7] = (BYTE)(wPosY&0x00FF); 				
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][7+bPacketNumber*7] = 0x10;
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][8+bPacketNumber*7] = 0;
						CustomerVar.bCustomerLastReportPoint = 1;
						wValidPoint |= 0x0001<< i;
						bCNT ++;
					}
					else
					{
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][2+bPacketNumber*7]=CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferSendIdx][2+bPacketNumber*7];
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][3+bPacketNumber*7]=CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferSendIdx][3+bPacketNumber*7];
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][4+bPacketNumber*7]=CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferSendIdx][4+bPacketNumber*7];
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][5+bPacketNumber*7]=CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferSendIdx][5+bPacketNumber*7];  
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][6+bPacketNumber*7]=CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferSendIdx][6+bPacketNumber*7]; 		
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][7+bPacketNumber*7]=CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferSendIdx][7+bPacketNumber*7]; 					 
						CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][8+bPacketNumber*7]=CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferSendIdx][8+bPacketNumber*7]; 
						bLeaveStatus = 1; 	
						CustomerVar.bCustomerLastReportPoint = 0;
					}
					bReportPoint |= 0x0001<< i;
				}
				else
				{
					CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][2+bPacketNumber*7]=0x00;
					CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][3+bPacketNumber*7]=0x00;
					CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][4+bPacketNumber*7]=0x00;
					CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][5+bPacketNumber*7]=0x00; 				
					CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][6+bPacketNumber*7]=0x00;
					CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][7+bPacketNumber*7]=0x00; 				
					CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][8+bPacketNumber*7]=0x00; 					
				}

				if(CustomerVar.bCustomReportCnt!=0xFF) 
				{
					CustomerVar.bCustomReportCnt++;
				} 
				else 
				{
					CustomerVar.bCustomReportCnt=0;
				} 

				bPacketNumber++;						
			}
		} 			 
			 
		if(bPacketNumber!=0)
		{
			CustomerVar.bINTtriggerCnt=0; //force to trigger INT Low
			CustomerVar.bCustomerReSendCNT=CUSTOMER_RESNED_NUM; //resend n times
			CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][1]=bReportPoint;

			if(bLeaveStatus==1)
			{
				CustomerVar.bCustomerReSendCNT++;
			}
		}
	} 			 
	else
	{
		CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferStoreIdx][0]=0;	
		if(CustomerVar.bCustomerReSendCNT == 2)
		{
			CustomerVar.bDoubleBufferStoreIdx= ((CustomerVar.bDoubleBufferStoreIdx+1)%2); 
		}
	}
	CustomerVar.wCustomerLastValidPoint=wValidPoint;
	CustomerVar.bCustomerLastReportFingerCNT=bCNT;				
	CustomerVar.bDoubleBufferSendIdx=CustomerVar.bDoubleBufferStoreIdx;

	if(CustomerVar.bCustomerReSendCNT>0) 
	{
		CustomerVar.bCustomerReSendCNT--;
	}
	if(CustomerVar.bCustomerReSendCNT!=0) 	 
	{
		CustomerVar.bINTtriggerCnt=0; //force to trigger INT Low							 
	}

	if(CustomerVar.bINTtriggerCnt==0) 	
	{ 	
		ZetVar.pbI2CnSPITxData = (BYTE *)(&CustomerVar.bDoubleBuffer[CustomerVar.bDoubleBufferSendIdx][0]);
		ZetVar.wI2CnSPITxIdx= 0;
		ZetVar.wI2CnSPITxLen = bPacketNumber*7+2; 
		ZetVar.wI2CnSPIRxIdx= 0;		
		if(I2C_INT()==TRUE) 
		{ 	
			I2C_INT_LOW(); 
		} 		
		CustomerVar.bINTtriggerCnt=0xFF; //Max value means disable		
	} 	
	else if(CustomerVar.bINTtriggerCnt!=0xFF&&CustomerVar.bINTtriggerCnt>0)  
	{
		CustomerVar.bINTtriggerCnt--;  
	}
}

void CustomerInit(void)
{  
	MEMSET((void *)&CustomerVar, 0, sizeof(CustomerVar));
}

#endif
