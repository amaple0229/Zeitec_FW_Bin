/**
 * @file SPI.c
 *
 * SPI Related Function
 *
 * @version $Revision: 62 $
 * @author JLJuang <JL.Juang@zeitecsemi.com>
 * @note Copyright (c) 2010, Zeitec Semiconductor Ltd., all rights reserved.
 * @note
*/


#include"ZetDEF.h"

#ifdef FEATURE_SPI_TRANSFER	
#define SPI_BUFFER_SIZE 100
BYTE SramSPI[SPI_BUFFER_SIZE];

BYTE CustomRes4Cmd1A_CODE[] = {0x1f,0x01,0x48,0x79,0x48,0x79,0x48,0x79,0x48,0x79,0x48,0x79,0x48,0x79,0x48,0x79};
BYTE CustomRes4Cmd19_CODE[] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
BYTE CustomRes4Cmd1A_2[] = {0x00,0x00};
BYTE CustomRes4Cmd1d[] = {0xe1,0x0e,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xef,0x00};
BYTE CustomRes4CmdEdata[50] = {0};
BYTE CustomRes4CmdEcmdbuff[20];
BYTE CustomCmdList[5][2] = {{0,0},{0,0},{0,0},{0,0},{0,0}} ;
BYTE CustomCmdListCnt=0;
BYTE CustomExDataCnt=0;


/**
 * @brief  SPIInit()
 *
 *  Init the SPI module
 *
 * @return NULL
 *
 */
void SPIInit(void)
{
	///////// set 4K sram as write buffer
	SPIBufferWriteEn();	 
	// SPISetNonIntTypeCmd();	 

	SPISetWakeupTypeCmd();				
	SPISramInit();
	SPISramReConfigure();
	// SPI2 continune command setting
	WRITE_REG(REG_SPI2_CMD0+2,0xf2);	
#if 1 //def FEATURE_DEVELOP1
	//setting all SPI cmd can wake-up mcu from deep-sleep mode
	SET_BIT(REG_SPI2_STATUS,1<<6);
#endif		
	// SPI buffer offset setting
	WRITE_REG32(SPI2_BUF_ADR,0);	
}

/*
void SPI_INT_HIGH(void)
{
   #if 0 //def FEATURE_DEVELOP1
	 //SET_MASK_BIT16(REG32_P3,(P35));
	 WRITE_REG16(REG32_P3, 0x2020);
   #else
   SET_BIT(REG32_P3,P35);
	 #endif
}

void SPI_INT_LOW(void)
{
   #if 0 //def FEATURE_DEVELOP1
	 //CLR_MASK_BIT16(REG32_P3,(P35));
	 WRITE_REG16(REG32_P3, 0x2000);
   #else
   CLR_BIT(REG32_P3,P35);
	 #endif
}

BYTE SPI_INT_STATUS(void)
{
   return (BYTE)I2C_INT();
}
*/

/**
 * @brief  SPISetNonIntTypeCmd()
 *
 *  Init the SPI module
 *
 * @return NULL
 *
 */
void SPISetNonIntTypeCmd(void)
{  
			 WRITE_REG(REG_SPI2_CMD0,0xf2);//// mask cmd, allow Max 4 cmd 
}

/**
 * @brief  SPISetWakeupTypeCmd()
 *
 *  Init the SPI module
 *
 * @return NULL
 *
 */
void SPISetWakeupTypeCmd(void)
{   
	//   WRITE_REG(REG_SPI2_CMD1,0x88);//////  wake up cmd, allow Max 4 cmd
	   WRITE_REG(REG_SPI2_CMD1,0x1C); 
}

/**
 * @brief  SPIBufferWriteEn()
 *
 *  Init the SPI module
 *
 * @return NULL
 *
 */
inline void SPIBufferWriteEn(void)
{  
    ///////// set 4K sram as write buffer
		CLR_BIT(REG_SPI2_STATUS,SPIBUF_WEN); //bit4:0:Can be written by External SPI HOST	 
}


void SPISramInit(void)
{  
	// BYTE i;
	ZetVar.bInterfaceType=SPI_TYPE;

	//SPI slave Rx buffer
	WRITE_REG32(REG_SPI2_TX_DMA_DEST_ADR,(unsigned char*)&bI2CRxBuf[0] );  
	WRITE_REG32(REG_SPI2_TX_DMA_DEST_MAX_ADR,((unsigned char*)&bI2CRxBuf[MAX_RX_BUF_LEN-1])); 	
	WRITE_REG32(REG_SPI2_TX_DMA_CNT,(MAX_RX_BUF_LEN));  

#ifdef FEATURE_SPI_CMD_REG_TYPE
	ZetVar.pbI2CnSPIRxData =(BYTE *)SPI2_DATA0; //set in I2Cinit, allocate others if I2C conflict with SPI
#endif

	//ZetVar.pbI2CnSPITxData = (BYTE *)&SramSPI[0];
	//SPI slave Tx buffer
	WRITE_REG32(REG_SPI2_RX_DMA_SRC_ADR,(unsigned char*)&ZetVar.pbI2CnSPITxData[0] );	
	WRITE_REG32(REG_SPI2_RX_DMA_SRC_MAX_ADR,((unsigned char*)&ZetVar.pbI2CnSPITxData[ ZetVar.wI2CnSPITxLen-1]));	 
	WRITE_REG32(REG_SPI2_RX_DMA_CNT,(ZetVar.wI2CnSPITxLen));	

	//WRITE_REG32(REG_SPI2_RX_DMA_SRC_ADR,(unsigned char*)&ZetVar.pbI2CnSPITxData[0] );	
	//WRITE_REG32(REG_SPI2_RX_DMA_SRC_MAX_ADR,((unsigned char*)&ZetVar.pbI2CnSPITxData[ZetVar.wI2CnSPITxLen-1]));	 
	//WRITE_REG32(REG_SPI2_RX_DMA_CNT,(ZetVar.wI2CnSPITxLen)-1);	

	CLR_BIT(REG_SPI2_FIFO_CTRL, 1<<0 );	 /// RX fifo		 MISO	 
#ifdef FEATURE_SPI_CMD_REG_TYPE
	SET_BIT(REG_SPI2_FIFO_CTRL, 1<<0 );	 /// RX fifo		 MISO
#endif

	CLR_BIT(REG_SPI2_FIFO_CTRL, 1<<1 );	/// for Master TX fifo	 MOSI	 
	SET_BIT(REG_SPI2_FIFO_CTRL, 1<<1 );	/// for Master TX fifo	 MOSI    
	///// 	RX first BUFFER / DUMMY BUFFER		
	WRITE_REG(REG_SPI2_RX_BUF, ZetVar.bROMCheckSum);	
}

#if 1

void SPISramReConfigure(void)
{ 			   
	WORD wlocalTxLen;

	if(ZetVar.bInterfaceType!=SPI_TYPE)
	{
	  return;
	}

	wlocalTxLen=ZetVar.wI2CnSPITxLen;

	if((ZetVar.bWorkingState==WORKING_STATE_ZET_CMD_STATE)
		||((ZetDF.cMiscRegister.scInterface.bRegSPIMode&0x20)==0x00))
	{
		//SPI slave Tx buffer, in Zetouch cmd state
		WRITE_REG32(REG_SPI2_RX_DMA_SRC_ADR,(unsigned char*)&ZetVar.pbI2CnSPITxData[0] );	
		if(wlocalTxLen>1)
		{			 
			WRITE_REG32(REG_SPI2_RX_DMA_SRC_MAX_ADR,((unsigned char*)&ZetVar.pbI2CnSPITxData[wlocalTxLen-1]));	 
			//WRITE_REG32(REG_SPI2_RX_DMA_CNT,(wlocalTxLen-1));
		}
		else
		{
			WRITE_REG32(REG_SPI2_RX_DMA_SRC_MAX_ADR,((unsigned char*)&ZetVar.pbI2CnSPITxData[0]));  
		}
		WRITE_REG32(REG_SPI2_RX_DMA_CNT,(wlocalTxLen));
	}
	else
	{
		//SPI slave Tx buffer, in custom state and 1st BYTE is data(no dummy BYTE) for iphone case 
		if(wlocalTxLen>1)
		{
			WRITE_REG32(REG_SPI2_RX_DMA_SRC_ADR,(unsigned char*)&ZetVar.pbI2CnSPITxData[1] );			 
			WRITE_REG32(REG_SPI2_RX_DMA_SRC_MAX_ADR,((unsigned char*)&ZetVar.pbI2CnSPITxData[wlocalTxLen-1]));	 
			WRITE_REG32(REG_SPI2_RX_DMA_CNT,65535);//(wlocalTxLen-1));
		}
		else
		{
			WRITE_REG32(REG_SPI2_RX_DMA_SRC_ADR,(unsigned char*)&ZetVar.pbI2CnSPITxData[0] );			 
			WRITE_REG32(REG_SPI2_RX_DMA_SRC_MAX_ADR,((unsigned char*)&ZetVar.pbI2CnSPITxData[0]));	 
			WRITE_REG32(REG_SPI2_RX_DMA_CNT,(wlocalTxLen));
		}
	}

	CLR_BIT(REG_SPI2_FIFO_CTRL, 1<<0 );	 /// RX fifo		 MISO		 
	SET_BIT(REG_SPI2_FIFO_CTRL, 1<<0 );	 /// RX fifo		 MISO
	//CLR_BIT(REG_SPI2_FIFO_CTRL, 1<<1 );	/// for Master TX fifo	 MOSI
	// SET_BIT(REG_SPI2_FIFO_CTRL, 1<<1 );	/// for Master TX fifo	 MOSI   
	if((ZetVar.bWorkingState==WORKING_STATE_ZET_CMD_STATE)
		||((ZetDF.cMiscRegister.scInterface.bRegSPIMode&0x20)==0x00))
	{
	}
	else if((ZetDF.cMiscRegister.scInterface.bRegSPIMode&0x20)==0x20)
	{
	 //in custom state and 1st BYTE is data(no dummy BYTE) for iphone case 
	 WRITE_REG(REG_SPI2_RX_BUF, ZetVar.pbI2CnSPITxData[0]); 
	}		 
}

#else
void SPISramReConfigure(void)
{ 			   
     if(ZetVar.bInterfaceType!=SPI_TYPE)
  	 {
        return;
  	 }
     //SPI slave Tx buffer
	   WRITE_REG32(REG_SPI2_RX_DMA_SRC_ADR,(unsigned char*)&ZetVar.pbI2CnSPITxData[0] );	
	   WRITE_REG32(REG_SPI2_RX_DMA_SRC_MAX_ADR,((unsigned char*)&ZetVar.pbI2CnSPITxData[ ZetVar.wI2CnSPITxLen-1]));	 
	   WRITE_REG32(REG_SPI2_RX_DMA_CNT,(ZetVar.wI2CnSPITxLen));	
	 
		 CLR_BIT(REG_SPI2_FIFO_CTRL, 1<<0 );	 /// RX fifo		 MISO
		 //CLR_BIT(REG_SPI2_FIFO_CTRL, 1<<1 );	/// for Master TX fifo	 MOSI
		 
		 SET_BIT(REG_SPI2_FIFO_CTRL, 1<<0 );	 /// RX fifo		 MISO
	  // SET_BIT(REG_SPI2_FIFO_CTRL, 1<<1 );	/// for Master TX fifo	 MOSI  

    
}
#endif






	
/**
 * @brief  SPIRxIsr()
 *
 *	Handle SPI RxIsr
 *
 * @return NULL
 *
 */

void SPIRxIsr(void)
{ 

  ZetVar.bInterfaceType=SPI_TYPE;
	#ifdef FEATURE_SPI_CMD_REG_TYPE
	ZetVar.pbI2CnSPIRxData =(BYTE *)SPI2_DATA0; //set in I2Cinit, allocate others if I2C conflict with SPI
  #endif
	//SPIDispatchCmd();
  I2CnSPIDispatchCmd();
	 
	#ifdef FEATURE_SPI_CMD_REG_TYPE
	#else
	//CLR_BIT(0x1A0015, 1<<0 ); /// for Master TX fifo 	MOSI
	//SET_BIT(0x1A0015, 1<<0 ); /// for Master TX fifo 	MOSI	 
	CLR_BIT(REG32_I2C_CTRL+1, 1<<0 ); /// for Master TX fifo 	MOSI
	SET_BIT(REG32_I2C_CTRL+1, 1<<0 ); /// for Master TX fifo 	MOSI	 
	
	CLR_BIT(REG_SPI2_FIFO_CTRL, 1<<1 ); /// for Master TX fifo	 MOSI
	SET_BIT(REG_SPI2_FIFO_CTRL, 1<<1 ); /// for Master TX fifo	 MOSI 	
    
	CLR_BIT(REG_SPI2_FIFO_CTRL, 1<<0 ); 	/// RX fifo 		MISO
				//CLR_BIT(REG_SPI2_FIFO_CTRL, 1<<1 );  /// for Master TX fifo 	MOSI
				
	SET_BIT(REG_SPI2_FIFO_CTRL, 1<<0 ); 	/// RX fifo 		MISO
			 // SET_BIT(REG_SPI2_FIFO_CTRL, 1<<1 );  /// for Master TX fifo 	MOSI			
  #endif 
	
////////////////////////////////////////////////////////////////
/// Maybe need to clear cmd buffer after parsed!!!
////////////////////////////////////////////////////////////////
		///--------------------------------------------///
		/// Clear interrupt flag
		///--------------------------------------------///
    WRITE_REG32(SPI2_IF, 0x0);
}

#ifdef FEATURE_CUSTOMER_PROTOCOL
void SPIDispatchCustomerCmd(void)
{
	// sample
	if(ZetVar.pbI2CnSPIRxData[0] == 0x1e)
	{		
		BYTE bTempbuff[] = {0x49,0x69};			
		CustomerResponseArray(bTempbuff,2,0);  
	}
	else if(ZetVar.pbI2CnSPIRxData[0] == 0x1f)
	{ 	
		BYTE bTempbuff[] = {0x4a,0xd1}; 		
		CustomerResponseArray(bTempbuff,2,0);  
	}
}

#endif //FEATURE_CUSTOMER_PROTOCOL
#endif

