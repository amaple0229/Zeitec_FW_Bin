/**
 * @file DFBitDefine.h
 *
 *  Register definition
 *
 * @note
*/
/// ===============================================================///
/// DEFINITION OF  ZetDF.cGlobalData.scPanelInformation.bICPackageType
/// ===============================================================///
#define PACKAGE_INT_PIN_BIT4  	(1<<4)
#define ZET7100_PACKAGE_TYPE_A  (0<<4)
#define ZET7100_PACKAGE_TYPE_B  (1<<4)
