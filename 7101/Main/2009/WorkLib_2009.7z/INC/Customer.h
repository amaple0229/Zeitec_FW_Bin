/**
 * @file Customer.h
 *
 *  Customer.h define the customer usage variables
 *
 *
 * @version $Revision: 2007 $
 * @author MapleHuang <maple.huang@zeitecsemi.com>
 * @note Copyright (c) 2018, Zeitec Semiconductor Ltd., all rights reserved.
 * @note
*/

#ifndef __CUSTOMER_H__
#define __CUSTOMER_H__

#include "ZetDEF.h"

#ifdef FEATURE_CUSTOMER_PROTOCOL

typedef struct PACK I2CCmdStructure
{
  BYTE const code *Cmdkey;
	//BYTE CmdSize;
  void (*CmdHF)(); 
} I2CCmdType;

typedef struct CustomerVarSt
{
	BYTE bINTtriggerCnt;
  WORD wCustomerLastValidPoint;
	BYTE bCustomerLastReportPoint;
	BYTE bCustomerBuf[CUSTOMER_BUF_LEN]; 
#ifdef FEATURE_ZET7101_CUSTOMER_TIMER2_ISR
	BYTE bToggleCnt;
#endif

	BYTE bCustomReportCnt; 
	BYTE bCustomerReSendCNT;	
	BYTE bCustomerLastReportFingerCNT;

	BYTE bDoubleBufferStoreIdx;
	BYTE bDoubleBufferSendIdx;
	BYTE bDoubleBuffer[2][40];
}CustomerVarType;

EXTERN CustomerVarType xdata CustomerVar; 

#endif	// FEATURE_CUSTOMER_PROTOCOL
#endif	// __CUSTOMER_H__