#ifndef __REVISION_H__
#define __REVISION_H__
/// ===========================================================================
///  Release Version
/// ===========================================================================

#define FW_VERSION  (1506)

//char *Date     = "2018/10/20 10:33";

//comment: Fix FHD issue

#endif ///< for __REVISION_H__

