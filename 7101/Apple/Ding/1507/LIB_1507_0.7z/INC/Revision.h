#ifndef __REVISION_H__
#define __REVISION_H__
/// ===========================================================================
///  Release Version
/// ===========================================================================

#define FW_VERSION  (1507)

//char *Date     = "2018/10/24 14:11";

//comment: Optimize FHP

#endif ///< for __REVISION_H__

