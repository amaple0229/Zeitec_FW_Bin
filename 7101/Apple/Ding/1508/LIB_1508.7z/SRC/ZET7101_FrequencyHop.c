/**
 * @file FrequencyHop.c
 *
 *  Task Oriented
 *
 * @version $Revision: 2 $
 * @author JLJuang <JL.Juang@zeitecsemi.com>
 * @note Copyright (c) 2010, Zeitec Semiconductor Ltd., all rights reserved.
 * @note
*/
#include "ZetDef.h"

#ifdef FEATURE_HW_FREQUENCY_HOP

void EnableNDConverter(void)
{
	//WRITE_REG(REG32_AD_CTRL0	,0x70);
	//WRITE_REG(REG32_AD_CTRL10 ,0x90);	

	WRITE_REG(REG32_AD_CTRL0	,AD_CTRL0_FREQHOP_SETUP);
	WRITE_REG(REG32_AD_CTRL10	,AD_CTRL10_FREQHOP_SETUP);	
	WRITE_REG(REG32_PN_CTRL		,PN_CTRL_NOISE_DETECT_ENABLE);
}
void StartNDConverter(void)
{
	WRITE_REG(REG_STR_PN_CTRL_3,START_ND_DETECT); ///< start Noise detect conversion
}
void ResetNDConverter(void)
{
	WRITE_REG(REG_STR_PN_CTRL_3,0x00); ///< disable Noise detect conversion
}
void WaitNDConverterDone(void)
{
	while((READ_REG32(REG32_PN_DEMOD_IF) == 0x00));
}

void MSHopBaseDataInit(void)
{
	int data i;	
	int data j;	
	for(i=0;i<MAX_HOP_NUM;i++)
	{
		for(j=0;j<HISTORY_SAVE_NUM;j++)
		{
			ZetVar.HopData[i].wADDeltaHistory[j] =0;		
		}
		ZetVar.HopData[i].wRawADBase = 0;
	}
}

void MSHopAccuDataInit(void)
{
	int data i;
	for(i=0;i<MAX_HOP_NUM;i++)
	{
		ZetVar.HopData[i].wADDeltaAccumulator =	0;
		ZetVar.HopData[i].wADDeltaSumation		=	0;
	}
}

void MSHopSortDataInit(void)
{
	int data i;
	for(i=0;i<FREQ_HOP_SORT_NUM;i++)
	{
		ZetVar.HopSortData[i].bHopID	 				= 0xFF;
		ZetVar.HopSortData[i].wHopData 				= 0xFFFF;			
	}
}
void MSHopDataInit(void)
{
	MSHopBaseDataInit();
	MSHopAccuDataInit();	
	MSHopSortDataInit();
}
void MSHopFreqRegisterSet(BYTE bToneDelta)
{
	WRITE_REG(REG32_FREQ_MULTIPLE_MIN_ND1	, ZetDF.cSYSFreqHop.scFreqHop.bFreqMulND1		+ bToneDelta);
	WRITE_REG(REG32_FREQ_MULTIPLE_DIFF_ND1, ZetDF.cSYSFreqHop.scFreqHop.bFreqMulDiff1	);
	WRITE_REG(REG32_FREQ_BIN_NUM_ND1			, ZetDF.cSYSFreqHop.scFreqHop.bFreqNum1			);
	WRITE_REG(REG32_FREQ_MULTIPLE_MIN_ND2	, ZetDF.cSYSFreqHop.scFreqHop.bFreqMulND2		+ bToneDelta);
	WRITE_REG(REG32_FREQ_MULTIPLE_DIFF_ND2, ZetDF.cSYSFreqHop.scFreqHop.bFreqMulDiff2	);
	WRITE_REG(REG32_FREQ_BIN_NUM_ND2			, ZetDF.cSYSFreqHop.scFreqHop.bFreqNum2			);
}

void MSHopSetupInit(void)
{
	BYTE data i;
	BYTE data j; 
	//BYTE bSenseGroupId = SENSE_GROUP_INIT;    
	///-------------------------------------------------------///  
	/// 1. Frequency Hop Setup
	///-------------------------------------------------------///
	//WRITE_REG(REG32_PN_DEMOD_IF,0x00);
	ResetADConverter();

	///-------------------------------------------------------///  
	/// 2. Reset All Pad to GND
	///-------------------------------------------------------///	
	TSAllTraceToGnd();

	///-------------------------------------------------------///  
	/// 3. Sense Axis Trace-Pad set to AD0
	///-------------------------------------------------------///
	for(j=0;j<SenseTraceAdcGroupNum;j++) ///< all RX connect to ADC
	{
		for(i=0;i<SenseTraceAdcGroup[j].bGroupSize;i++)
		{
  		PAD_SEL[SenseTraceAdcGroup[j].bPad[i]] = 0x10; ///< use ADC0 to detect noise
		}
	}
}

void MSHopScan(BYTE bScanSampleNum)
{
	BYTE data i;
	BYTE data k;
	BYTE data bFreqHopNum;
	BYTE data bFreqHopToneNum;

	int xdata iCurrentAD;
	int xdata iADDeltaSum;
	int xdata iDevError = (WORD)ZetDF.cSYSFreqHop.scDynamicHop.bDynamicHopDevErr;
	volatile unsigned int * pSramTablePnDemod = (volatile unsigned int *)SRAM_PN_DEMOD;
	bFreqHopNum 		= ZetDF.cSYSFreqHop.scFreqHop.bFreqHopSetNum;
	bFreqHopToneNum = ZetDF.cSYSFreqHop.scFreqHop.bFreqHopToneRound; 

	///-------------------------///
	/// Clear Raw
	///-------------------------///	
	for(i=0;i<bFreqHopNum;i++)
	{
		ZetVar.HopData[i].wRawADBase =0;
	}
	for(k=0;k<bFreqHopToneNum;k++)
	{	
		///-------------------------------------------------------///  
		/// 0. Start ND converter
		///-------------------------------------------------------///	
		MSHopFreqRegisterSet(k<<1); ///< ToneA start:ND1 => ToneB start:ND1+2
		ResetADConverter();
		///-------------------------------------------------------///  
		/// 1. Start ND converter
		///-------------------------------------------------------///				
		StartNDConverter();
		WaitNDConverterDone();
		ResetNDConverter();
		
		///-------------------------------------------------------///  
		/// 2. Get ND ADBase /AD Delta
		///-------------------------------------------------------///
		WRITE_REG(REG_EXT_SRAM_CTRL,REG_EXT_SRAM_CTRL_FW_ENABLE);	

		for(i=0;i<bFreqHopNum;i++)
		{
			iCurrentAD = pSramTablePnDemod[i];
			if(iCurrentAD > ZetVar.HopData[i].wRawADBase)
			{
				ZetVar.HopData[i].wRawADBase = iCurrentAD;
			}
			/*/-----------------------------------------------------------//
			// Get Max
			//-----------------------------------------------------------//
			if(iCurrentAD > ZetVar.HopData[i].wADDeltaAccumulator)
			{
				ZetVar.HopData[i].wADDeltaAccumulator = iCurrentAD;
			}
			//-----------------------------------------------------------/*/
			// Accumulate
			//-----------------------------------------------------------//			
			iCurrentAD = iCurrentAD/bScanSampleNum;			
			if(iCurrentAD < iDevError)
			{
				continue;
			}
			iADDeltaSum = (int)(ZetVar.HopData[i].wADDeltaAccumulator) + iCurrentAD;
			if(iADDeltaSum > 0xFFFF)
			{
				iADDeltaSum = 0xFFFF;
			}
			ZetVar.HopData[i].wADDeltaAccumulator = (WORD)iADDeltaSum;
			//-----------------------------------------------------------//*/
		}
		WRITE_REG(REG_EXT_SRAM_CTRL,REG_EXT_SRAM_CTRL_FW_DISABLE);	
	}	
	///-------------------------------------------------------///  
	/// 3. Reset AD
	///-------------------------------------------------------///
	ResetADConverter();
}

void MSHopDataMerge(void)
{
	int data i;
	int data iAccuData;
	BYTE data bFreqHopNum;
	bFreqHopNum = ZetDF.cSYSFreqHop.scFreqHop.bFreqHopSetNum;
	for(i=0;i<bFreqHopNum;i++)	
	{
		iAccuData = (ZetVar.HopData[i].wADDeltaAccumulator);
		if(iAccuData > ZetVar.HopData[i].wADDeltaSumation)
		{
			ZetVar.HopData[i].wADDeltaSumation = iAccuData;
		}
		ZetVar.HopData[i].wADDeltaAccumulator = 0;
	}
}
void MSHopTrimSortResult(void)
{
	BYTE  data i;
	BYTE  data j;
	BYTE  data k;
	BYTE data bFreqHopNum;
	bFreqHopNum = ZetDF.cSYSFreqHop.scFreqHop.bFreqHopSetNum;
	WORD  xdata wFreqSetNumDeltaDev;	
	for(i=0;i<bFreqHopNum;i++)
	{
		wFreqSetNumDeltaDev = ZetVar.HopData[i].wADDeltaSumation;
		for(j=0;j<FREQ_HOP_SORT_NUM;j++)
		{
			if(wFreqSetNumDeltaDev < ZetVar.HopSortData[j].wHopData)
			{
				for(k=(FREQ_HOP_SORT_NUM-1);k>j;k--)
				{
					ZetVar.HopSortData[k].wHopData = ZetVar.HopSortData[k-1].wHopData;
					ZetVar.HopSortData[k].bHopID   = ZetVar.HopSortData[k-1].bHopID;
				}
				ZetVar.HopSortData[j].wHopData = wFreqSetNumDeltaDev;
				ZetVar.HopSortData[j].bHopID	 = i;
				break;
			}
		}
	}
}

void MSHopSetMinNoiseToneID(void)
{
	if(ZetVar2.bNowToneID != ZetVar2.bGoodToneID)
	{
		ZetVar2.bChangeCnt ++;
		ZetVar2.bNowToneID = ZetVar2.bGoodToneID;//ZetVar.HopSortData[0].bHopID;
	}
	SYSSetFreqToneReg(ZetVar2.bNowToneID);	
	//LM, test
  WRITE_REG(	REG32_RX_FREQ_MULTIPLEA , ZetVarPara.bCmdPara[SPARA_TONEA]);	///< Tone A setup
  WRITE_REG(	REG8_PN_SINE_NUM_A	 , ZetVarPara.bCmdPara[SPARA_TONEA]);	///< PN Sine Num A
  WRITE_REG16(REG32_SINE_FREQ_SCALE 	, (WORD)((ZetVarPara.bCmdPara[SPARA_TONEB]<<8) + ZetVarPara.bCmdPara[SPARA_TONEA]));	
}

#ifdef FEATURE_BOOT_FREQUENCY_HOP 
void TaskBootUpFrequencyHop(void)
{
	BYTE data  i;
	BYTE data  bHopDataGetRounds;	
  BYTE data  bPnctrlBackup;
	BYTE data  bADCtrl0Backup;
	BYTE data  bADCtrl10Backup;
	//BYTE data  bFreqHopNum;	
	//bFreqHopNum     = ZetDF.cSYSFreqHop.scFreqHop.bFreqHopSetNum;	
	if(ZetDF.cSYSFreqHop.scFreqSetup.bFreqHopTimesWhenReset == 0)
	{
		return;
	}
	if(ZetVar.wTestMode & TP_TEST_ITO_SENSOR) 
	{
		return;
	}
	
	///-------------------------------------------------------///  
	/// 1. BackUp Register Setup
	///-------------------------------------------------------///
  bPnctrlBackup		=	READ_REG(REG32_PN_CTRL);
	bADCtrl0Backup	=	READ_REG(REG32_AD_CTRL0);
	bADCtrl10Backup	=	READ_REG(REG32_AD_CTRL10);	

	///-------------------------------------------------------///  
	/// 2. Frequency Hop Setup
	///-------------------------------------------------------///
	IntAdcDisable();
	EnableNDConverter();	
#ifdef FEATRUE_USED_LESS_ADC
  ADCLessPowerOn(CAP_MODE);
#else
  ADCPowerOn(CAP_MODE);
#endif
	
	MSHopSetupInit();
	MSHopDataInit();

	///-------------------------------------------------------///  
	/// 3. Frequency Hop Scan Get Base
	///-------------------------------------------------------///		
	//MSHopScan(); 

	///-------------------------------------------------------///  
	/// 4. Frequency Hop Scan Get Delta accumulate
	///-------------------------------------------------------///
	bHopDataGetRounds = ZetDF.cSYSFreqHop.scFreqSetup.bFreqHopTimesWhenReset;	
	for(i=0;i<bHopDataGetRounds;i++)
	{ 
		if(ZetVar.wTestMode & TP_TEST_ITO_SENSOR) 
		{
			return;
		}
		
		MSHopScan(ZetDF.cSYSFreqHop.scFreqSetup.bFreqHopTimesWhenReset);	
		MSHopDataMerge();  	
	}
	//if noise level is not large, use default bFreqHopCurrentID Tone(usually = TONE_A_MUL)!!!
	//make sure  bFreqHopCurrentID Tone map to TONE_A_MUL 
	if(ZetVar.HopData[ZetVar2.bNowToneID].wADDeltaSumation >= ZetDF.cSYSFreqHop.scDynamicHop.wDynamicHopDevSumTH) 
	{
		MSHopTrimSortResult();
		ZetVar2.bGoodToneID = ZetVar.HopSortData[0].bHopID;
		MSHopSetMinNoiseToneID();
	}
	///-------------------------------------------------------///  
	/// 4. Frequency Hop End Register recovery
	///-------------------------------------------------------///
	WRITE_REG(REG32_PN_CTRL		,	bPnctrlBackup);
	WRITE_REG(REG32_AD_CTRL0	,	bADCtrl0Backup);
	WRITE_REG(REG32_AD_CTRL10	,	bADCtrl10Backup); 
	ADCPowerOff(CAP_MODE);
	ResetADConverter();
	TSAllTraceToGnd();
}
#endif

#ifdef FEATURE_DYNAMIC_FREQUENCY_HOP 
void DynamicRecentScanDataRecovery(void)
{
	int data i;	
	int data j;		
	int xdata iMaxHistoryAccuData;	
	BYTE data bFreqHopNum;

	bFreqHopNum	= ZetDF.cSYSFreqHop.scFreqHop.bFreqHopSetNum;
	
	for(i=0;i<bFreqHopNum;i++)	
	{
		ZetVar.HopData[i].wADDeltaAccumulator = 0;		
		iMaxHistoryAccuData = 0;
		for(j=0;j<HISTORY_SAVE_NUM;j++)	
		{
			if(iMaxHistoryAccuData < ZetVar.HopData[i].wADDeltaHistory[j])
			{
				iMaxHistoryAccuData = ZetVar.HopData[i].wADDeltaHistory[j];
			}
		}
		ZetVar.HopData[i].wADDeltaSumation	=	(ZetVar.HopData[i].wADDeltaSumation>>2)*3 + (iMaxHistoryAccuData>>2);
	}
}
void DynamicScanRoundCtrl(void)
{
	ZetVar2.bDynamicFreqHopScanCnt ++; 	
	if(ZetVar2.bDynamicFreqHopScanCnt >= ZetDF.cSYSFreqHop.scDynamicHop.bDynamicScanSampleNum)
	{
		ZetVar2.bDynamicFreqHopScanCnt = 0;
		ZetVar2.bDynamicFreqStatus |= DYNAMIC_HOP_ROUND_FINISH;
		ZetVar2.bDynamicFreqStatus &= ~(DYNAMIC_HOP_QUCIK_SCAN_EN );	
	}
}
void DynamicFreqCurrentIDScanCheck(void)
{
	int data iNowIDDeltaData;

	if(ZetVar2.bDynamicFreqStatus & DYNAMIC_HOP_QUCIK_SCAN_EN)
	{
		return;
	}
	
	iNowIDDeltaData = ZetVar.HopData[ZetVar2.bNowToneID].wADDeltaAccumulator;	
	if(iNowIDDeltaData >= ZetDF.cSYSFreqHop.scDynamicHop.wDynamicHopDevQuickTH)
	{		
			ZetVar2.bDynamicCurrentIDBadCnt ++;
			//if(ZetVar2.bDynamicCurrentIDBadCnt > 2)
			if(ZetVar2.bDynamicCurrentIDBadCnt >= ZetDF.cSYSFreqHop.scDynamicHop.bDynamicHopDevQuickCnt) 
			{				
				ZetVar2.bDynamicFreqStatus |= (DYNAMIC_HOP_QUCIK_SCAN_EN);		
				ZetVar2.bDynamicCurrentIDBadCnt = 0;
			}				
	}
	else
	{	
		ZetVar2.bDynamicCurrentIDBadCnt = 0;
	}
	
}

void DynamicScanDataAnalysis(void)
{
	BYTE data i;
	int data iAccuData;
	int data iSum;
	int data iAvg;	
	int data iNowIDADSum;	
	
	BYTE data bFreqHopNum;
	BYTE data bNewID;
	WORD wFreqHopTH;

	if(ZetVar2.bChangeCnt < ZetDF.cSYSFreqHop.scFreqHop.bFreqChangeCntTH)
	{
		wFreqHopTH = ZetDF.cSYSFreqHop.scDynamicHop.wDynamicHopDevSumTH >> 1;
	}
	else
	{
		wFreqHopTH = ZetDF.cSYSFreqHop.scDynamicHop.wDynamicHopDevSumTH;
	}
	bFreqHopNum	= ZetDF.cSYSFreqHop.scFreqHop.bFreqHopSetNum;

	if(!(ZetVar2.bDynamicFreqStatus & DYNAMIC_HOP_ROUND_FINISH))
	{
		return;
	}
	ZetVar2.bDynamicFreqStatus &= ~(DYNAMIC_HOP_ROUND_FINISH);	

	///------------------------------------------///
	/// Merge Accumulate Data , 
	/// Record History Data	 ,
	/// Average All Freq-Set Data
	///------------------------------------------///
	ZetVar2.bDynamicHistoryCnt = (ZetVar2.bDynamicHistoryCnt+1)%(HISTORY_SAVE_NUM);	
	iSum = 0;
	for(i=0;i<bFreqHopNum;i++)
	{
		iAccuData = (ZetVar.HopData[i].wADDeltaAccumulator);
		if(iAccuData > ZetVar.HopData[i].wADDeltaSumation)
		{
			ZetVar.HopData[i].wADDeltaSumation = iAccuData;
		}		
		iSum += ZetVar.HopData[i].wADDeltaSumation;
		ZetVar.HopData[i].wADDeltaHistory[ZetVar2.bDynamicHistoryCnt] = iAccuData;		
		ZetVar.HopData[i].wADDeltaAccumulator = 0;
	}
	iAvg = iSum/bFreqHopNum;

	if(ZetVar.wSysMode & SYS_MODE_FINGER_TOUCHED)
	{
		ZetVar2.bDynamicFreqHopRoundCnt++;
	}	
	else
	{
		ZetVar2.bDynamicFreqHopRoundCnt = 0;
	}
	
	///------------------------------------------///
	/// Check Now Freq is Good/Bad 
	///------------------------------------------///
	iNowIDADSum = ZetVar.HopData[ZetVar2.bNowToneID].wADDeltaSumation;
	if( (iNowIDADSum <= wFreqHopTH) 
			|| (iNowIDADSum < iAvg)
			)
	{
		if(ZetVar2.bDynamicFreqHopRoundCnt < ZetDF.cSYSFreqHop.scDynamicHop.bDynamicHopResetRound)
		{
			return;
		}
	}
	else
	{
		///------------------------------------------///
		/// Sort Accumulate Data                     ///
		///------------------------------------------///
		MSHopSortDataInit();
		MSHopTrimSortResult();
		bNewID = ZetVar.HopSortData[0].bHopID;///< Get the Smallest Noise FreqID
		//LM, test, new Tone noise Dev need also small than 7/8 current Tone Noise Dev 
		if( (WORD)iNowIDADSum*(ZetDF.cSYSFreqHop.scFreqHop.bFreqNoiseDiff)/8 > ZetVar.HopSortData[0].wHopData)
		{
			if(ZetVar2.bNowToneID != bNewID)
			{
				ZetVar2.bGoodToneID = bNewID;
				ZetVar2.bDynamicFreqStatus |= DYNAMIC_HOP_EXECUTE;
			}
		}
	}
	ZetVar2.bDynamicFreqHopRoundCnt = 0;
	ZetVar2.bDynamicFreqStatus |= DYNAMIC_HOP_RESET_DATABASE;
}

void TaskDynamicUpFrequencyHop(void)
{
	BYTE data  bPnctrlBackup;
	BYTE data  bADCtrl0Backup;
	BYTE data  bADCtrl10Backup;

	if(ZetDF.cSYSFreqHop.scDynamicHop.bDynamicScanSampleNum == 0)
	{
		return;
	}
	if(ZetVar.wTestMode & TP_TEST_ITO_SENSOR) 
	{
		return;
	}		
	///-------------------------------------------------------///  
	/// 1. BackUp Register Setup
	///-------------------------------------------------------///
  bPnctrlBackup		=	READ_REG(REG32_PN_CTRL);
	bADCtrl0Backup	=	READ_REG(REG32_AD_CTRL0);
	bADCtrl10Backup	=	READ_REG(REG32_AD_CTRL10);	

	IntAdcDisable();
	EnableNDConverter();	
#ifdef FEATRUE_USED_LESS_ADC
  ADCLessPowerOn(CAP_MODE);
#else
  ADCPowerOn(CAP_MODE);
#endif
	MSHopSetupInit();
	///-------------------------------------------------------///  
	/// 2. ND Scan
	///-------------------------------------------------------///	
	while(1)
	{	
		MSHopScan(ZetDF.cSYSFreqHop.scDynamicHop.bDynamicScanSampleNum);
		DynamicFreqCurrentIDScanCheck();
		DynamicScanRoundCtrl();
		DynamicScanDataAnalysis();
		if(!(ZetVar2.bDynamicFreqStatus & DYNAMIC_HOP_QUCIK_SCAN_EN))
		{
			break;
		}
	}
	
	///-------------------------------------------------------///  
	/// 3. Frequency Hop End Register recovery
	///-------------------------------------------------------///
	WRITE_REG(REG32_PN_CTRL 	, bPnctrlBackup);
	WRITE_REG(REG32_AD_CTRL0	, bADCtrl0Backup);
	WRITE_REG(REG32_AD_CTRL10 , bADCtrl10Backup); 
	ADCPowerOff(CAP_MODE);
	ZetVar2.bDynamicFreqStatus &= ~(DYNAMIC_HOP_QUCIK_SCAN_EN );	
	ResetADConverter();
	TSAllTraceToGnd();
}
#endif
#endif
